<?php

namespace FFLHub\Distributor;

if (! defined('ABSPATH')) {
    exit;
}

use FFLHub\Settings\Options;
use FFLHub\Distributor\Product\DistributorProductPayload;
use FFLHub\Distributor\Product\DistributorProductSyncCronService;

/**
 * Central place to build and expose distributor instances.
 *
 * Now builds distributors via module instances from DistributorRegistry.
 * Also handles enabling/disabling distributors (including starting/stopping services).
 */
class DistributorHandler
{
    /**
     * @var array<string, DistributorBase>
     */
    private array $distributors = [];

    private DistributorProductSyncCronService $productSyncCronService;

    public function __construct()
    {
        $this->register_distributors();
    }

    private function register_distributors(): void
    {
        foreach (DistributorRegistry::get_modules() as $module) {
            $dist = $module->build_distributor();
            $this->distributors[$module->id()] = $dist;
        }

        $this->productSyncCronService = new DistributorProductSyncCronService();
    }

    /**
     * Enable or disable a distributor (and start/stop its services).
     */
    public function set_enabled(string $id, bool $enabled): void
    {
        $id = trim($id);
        if ($id === '') {
            return;
        }

        // Persist the state.
        Options::set_distributor_enabled($id, $enabled);

        // Retrieve the distributor.
        $dist = $this->distributors[$id] ?? null;
        if (! $dist) {
            return;
        }

        $services = $dist->get_services();
        if (! $services) {
            return;
        }

        // Hard start/stop cron + runtime services.
        if ($enabled) {
            $services->on_activate();
        } else {
            $services->on_deactivate();
        }
    }

    /**
     * @return array<string, DistributorBase>
     */
    public function get_distributors(): array
    {
        return $this->distributors;
    }

    public function get_distributor_by_id(string $id): ?DistributorBase
    {
        return $this->distributors[$id] ?? null;
    }

    public function on_activate(): void
    {
        foreach ($this->distributors as $id => $distributor) {
            // Only start enabled distributors on plugin activation.
            if (! Options::is_distributor_enabled($id)) {
                continue;
            }

            $services = $distributor->get_services();
            if ($services) {
                $services->on_activate();
            }
        }

        $this->productSyncCronService->on_activation();
    }

    public function on_deactivate(): void
    {
        foreach ($this->distributors as $distributor) {
            $services = $distributor->get_services();
            if ($services) {
                $services->on_deactivate();
            }
        }

        $this->productSyncCronService->on_deactivation();
    }

    public function register_runtime_services(): void
    {
        foreach ($this->distributors as $id => $distributor) {
            if (! Options::is_distributor_enabled($id)) {
                continue;
            }

            $services = $distributor->get_services();
            if ($services) {
                $services->register_runtime_services();
            }
        }

        $this->productSyncCronService->register();
    }

    /**
     * Fetch normalized distributor payloads for a UPC across all distributors.
     *
     * @return array{
     *   carriers: array<string,array{label:string,payload:DistributorProductPayload,true_cost:?float,quantity:?int}>,
     *   cheapest_in_stock: ?array{product:DistributorProductPayload,true_cost:float,label:string,id:string,quantity:?int},
     *   cheapest_any: ?array{product:DistributorProductPayload,true_cost:float,label:string,id:string,quantity:?int}
     * }
     */
    public function get_payloads_for_upc(string $upc): array
    {
        $upc = trim($upc);

        $carriers          = [];
        $cheapest_in_stock = null;
        $cheapest_any      = null;

        if ($upc === '') {
            return [
                'carriers'          => $carriers,
                'cheapest_in_stock' => $cheapest_in_stock,
                'cheapest_any'      => $cheapest_any,
            ];
        }

        foreach ($this->distributors as $id => $distributor) {
            // Skip disabled distributors.
            if (! Options::is_distributor_enabled($id)) {
                continue;
            }

            try {
                $product = $distributor->get_product_by_upc($upc);
            } catch (\Throwable $e) {
                continue;
            }

            if (! ($product instanceof DistributorProductPayload)) {
                continue;
            }

            $label = $distributor->get_label();

            $payload_array = get_object_vars($product);

            $true_cost = null;
            if (isset($payload_array['true_cost']) && $payload_array['true_cost'] !== null && $payload_array['true_cost'] !== '') {
                $true_cost = (float) $payload_array['true_cost'];
                if ($true_cost <= 0) {
                    $true_cost = null;
                }
            }

            $quantity = null;
            if (isset($payload_array['quantity']) && $payload_array['quantity'] !== null && $payload_array['quantity'] !== '') {
                $quantity = (int) $payload_array['quantity'];
            }

            $key = (string) $id;

            $carriers[$key] = [
                'label'     => $label,
                'payload'   => $product,
                'true_cost' => $true_cost,
                'quantity'  => $quantity,
            ];

            if ($true_cost !== null) {
                if ($cheapest_any === null || $true_cost < $cheapest_any['true_cost']) {
                    $cheapest_any = [
                        'product'   => $product,
                        'true_cost' => $true_cost,
                        'label'     => $label,
                        'id'        => $key,
                        'quantity'  => $quantity,
                    ];
                }

                if ($quantity !== null && $quantity > 0) {
                    if ($cheapest_in_stock === null || $true_cost < $cheapest_in_stock['true_cost']) {
                        $cheapest_in_stock = [
                            'product'   => $product,
                            'true_cost' => $true_cost,
                            'label'     => $label,
                            'id'        => $key,
                            'quantity'  => $quantity,
                        ];
                    }
                }
            }
        }

        return [
            'carriers'          => $carriers,
            'cheapest_in_stock' => $cheapest_in_stock,
            'cheapest_any'      => $cheapest_any,
        ];
    }
}
