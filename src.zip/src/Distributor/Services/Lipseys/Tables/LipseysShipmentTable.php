<?php

namespace FFLHub\Distributor\Services\Lipseys\Tables;

use FFLHub\Distributor\Services\Tables\DistributorTableInterface;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Physical table manager for the Lipsey's shipment ingestion table.
 *
 * Responsibilities:
 *  - Create / migrate the shipments table using dbDelta().
 *  - Provide table name resolution helpers.
 *
 * This is intentionally SIMPLE:
 *  - Single table (no swapping, no staging).
 *  - Append-only usage model.
 */
final class LipseysShipmentTable implements DistributorTableInterface
{
    /**
     * @var LipseysShipmentSchema
     */
    private $schema;

    public function __construct(LipseysShipmentSchema $schema)
    {
        $this->schema = $schema;
    }

    /**
     * Fully-qualified table name (with WP prefix).
     */
    public function get_table_name(): string
    {
        global $wpdb;

        return $wpdb->prefix . $this->schema->get_base_table_key();
    }

    /**
     * Create or migrate the shipments table.
     *
     * Uses dbDelta so schema changes are applied safely.
     */
    public function createTables(): void
    {
        global $wpdb;

        $table   = $this->get_table_name();
        $charset = $wpdb->get_charset_collate();

        $cols    = $this->schema->get_column_definitions();
        $indexes = $this->schema->get_index_definitions();

        $lines = [];

        foreach ($cols as $name => $def) {
            $lines[] = "{$name} {$def}";
        }

        foreach ($indexes as $idx_def) {
            $lines[] = $idx_def;
        }

        $sql = "CREATE TABLE {$table} (\n" .
               implode(",\n", $lines) .
               "\n) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        dbDelta($sql);
    }

    /**
     * Interface requirement.
     *
     * Not applicable for shipments (no UPC concept),
     * so always returns null.
     */
    public function get_row_by_upc($upc): ?array
    {
        return null;
    }
}
