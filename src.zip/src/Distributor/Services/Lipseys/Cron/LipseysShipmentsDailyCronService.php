<?php

namespace FFLHub\Distributor\Services\Lipseys\Cron;

use FFLHub\Distributor\Services\Cron\AbstractCronService;
use FFLHub\Distributor\Services\Lipseys\Tables\LipseysShipmentTable;

if (! defined('ABSPATH')) {
    exit;
}

/**
 * Daily job:
 * - Calls Lipsey's Shipping/OneDay for the previous day (UTC)
 * - Upserts results into the Lipsey's shipment table keyed by PO number
 */
final class LipseysShipmentsDailyCronService extends AbstractCronService
{
    private const CRON_HOOK = 'fflhub_lipseys_shipments_daily';

    private LipseysShipmentTable $shipmentTable;

    public function __construct(LipseysShipmentTable $shipmentTable)
    {
        $this->shipmentTable = $shipmentTable;
    }

    public function get_cron_hook_name(): string
    {
        return self::CRON_HOOK;
    }

    /**
     * Use Action Scheduler now. So schedule keys here are only informational
     * (or used if your AbstractCronService still supports WP-Cron fallback).
     */
    protected function get_schedule_key(): string
    {
        return 'fflhub_daily';
    }

    protected function get_interval_seconds(): int
    {
        return DAY_IN_SECONDS;
    }

    protected function get_interval_display(): string
    {
        return __('Daily (FFLHub Lipsey\'s Shipments)', 'ffl-hub');
    }

    /**
     * Daily jobs can start ~a couple mins after activation.
     */
    protected function get_initial_delay_seconds(): int
    {
        return 120;
    }

    public function run(): void
    {
        $t0 = microtime(true);

        $this->log_debug('[FFLHub][Lipsey\'s Shipments Cron] ---- RUN START ----');

        // Always ensure table exists (safe + idempotent).
        // If you prefer: do this only in on_activation(), but doing it here is “belt + suspenders”.
        if (method_exists($this->shipmentTable, 'createTables')) {
            $this->shipmentTable->createTables();
        }

        // Target previous day (UTC) — matches Lipsey’s guidance "use once a day, target previous day".
        // Format: "n/j/Y" like their examples (7/20/2019)
        $yesterday_utc = gmdate('n/j/Y', time() - DAY_IN_SECONDS);

        $this->log_debug('[FFLHub][Lipsey\'s Shipments Cron] target_date=' . $yesterday_utc);

        /**
         * TODO (next step):
         *  - Call the Lipsey’s API Integration/Shipping/OneDay
         *  - Validate response
         *  - Normalize rows
         *  - Upsert into shipments table
         *
         * For now we’ll just log the date so you can confirm scheduling runs.
         */

        $elapsed_ms = (microtime(true) - $t0) * 1000.0;

        $this->log_debug(
            sprintf(
                '[FFLHub][Lipsey\'s Shipments Cron] ---- RUN END (total_ms=%.2f) ----',
                $elapsed_ms
            )
        );
    }

    private function log_debug(string $message): void
    {
        if (! defined('FFLHUB_CRON_DEBUG') || FFLHUB_CRON_DEBUG !== true) {
            return;
        }

        error_log($message);
    }
}
