<?php

namespace FFLHub\Distributor\Services\Orders\Shipping;

use FFLHub\Distributor\Services\Orders\OrderPlacementKeys;
use FFLHub\Distributor\Services\Tables\OrderPlacementJobsTable;
use FFLHub\Distributor\Services\Cron\AbstractCronService;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Shipping poll scheduler + selector.
 *
 * Phase 1:
 *  - Selects eligible jobs needing shipment polling
 *  - Logs them
 *  - Stamps last_shipping_poll_at
 *
 * Does NOT call distributor APIs yet.
 */
final class OrderPlacementShippingPollCronService extends AbstractCronService
{
    private const LOG_PREFIX = '[FFLHUB][ShippingPoller]';

    /**
     * Action Scheduler hook name.
     */
    public const CRON_HOOK = 'fflhub_place_shipping_poll';

    /**
     * Minimum spacing between polls per job (minutes).
     */
    private const JOB_MIN_POLL_INTERVAL_MINUTES = 60;

    /**
     * How many jobs to process per run.
     */
    private const BATCH_LIMIT = 50;

   

    /**
     * Unique cron hook name.
     */
    public function get_cron_hook_name(): string
    {
        return self::CRON_HOOK;
    }


    /**
     * Action Scheduler group.
     *
     * Keeping this separate from catalog jobs avoids worker contention later
     * when you start doing API polling here.
     */
    public function get_action_group(): string
    {
        return 'fflhub_shipping';
    }

    /**
     * How often the poller runs.
     */
    protected function get_interval_seconds(): int
    {
        return 15 * MINUTE_IN_SECONDS;
    }

    /**
     * Initial delay before first run.
     */
    protected function get_initial_delay_seconds(): int
    {
        return 60; // 1 minute
    }

    /**
     * Worker entrypoint.
     */
    public function run(): void
    {
        global $wpdb;

        $table = OrderPlacementJobsTable::get_table_name();

        // Poll spacing per row
        $min_interval_seconds = self::JOB_MIN_POLL_INTERVAL_MINUTES * 60;
        $cutoff_unix          = time() - $min_interval_seconds;
        $cutoff_mysql_utc     = gmdate('Y-m-d H:i:s', $cutoff_unix);

        $limit = self::BATCH_LIMIT;

        // Note: timestamps stored as UTC (DATETIME without TZ)
        $sql = $wpdb->prepare(
            "
            SELECT
                id, order_id, job_key, dist_id, bucket, status,
                merchant_po, external_order_id,
                shipped_at, last_shipping_poll_at
            FROM {$table}
            WHERE
                status = %s
                AND merchant_po IS NOT NULL
                AND merchant_po <> ''
                AND (shipped_at IS NULL OR shipped_at = '0000-00-00 00:00:00')
                AND (
                    last_shipping_poll_at IS NULL
                    OR last_shipping_poll_at = '0000-00-00 00:00:00'
                    OR last_shipping_poll_at < %s
                )
            ORDER BY
                last_shipping_poll_at IS NULL DESC,
                last_shipping_poll_at ASC,
                id ASC
            LIMIT %d
            ",
            OrderPlacementKeys::JOB_STATUS_SUCCESS,
            $cutoff_mysql_utc,
            $limit
        );

        $rows = $wpdb->get_results($sql, ARRAY_A);

        if (!is_array($rows) || empty($rows)) {
            $this->log_debug('no jobs eligible for shipping poll');
            return;
        }

        $this->log_debug(
            sprintf(
                'eligible jobs=%d cutoff=%s',
                count($rows),
                $cutoff_mysql_utc
            )
        );

        foreach ($rows as $r) {
            $order_id = isset($r['order_id']) ? (int) $r['order_id'] : 0;
            $job_key  = isset($r['job_key']) ? (string) $r['job_key'] : '';
            $dist_id  = isset($r['dist_id']) ? (string) $r['dist_id'] : '';
            $bucket   = isset($r['bucket']) ? (string) $r['bucket'] : '';
            $po        = isset($r['merchant_po']) ? (string) $r['merchant_po'] : '';
            $ext       = isset($r['external_order_id']) ? (string) $r['external_order_id'] : '';

            // Stamp last_shipping_poll_at now
            OrderPlacementShippingStore::touch_last_shipping_poll_at(
                $order_id,
                $job_key
            );

            $this->log_debug(
                sprintf(
                    'would_poll order=%d job=%s dist=%s bucket=%s po=%s external=%s',
                    $order_id,
                    $job_key,
                    $dist_id,
                    $bucket,
                    $po,
                    $ext
                )
            );
        }
    }

    /**
     * Debug logger.
     */
    private function log_debug(string $message): void
    {
        if (!defined('FFLHUB_CRON_DEBUG') || FFLHUB_CRON_DEBUG !== true) {
            return;
        }

        error_log(self::LOG_PREFIX . ' ' . $message);
    }
}
