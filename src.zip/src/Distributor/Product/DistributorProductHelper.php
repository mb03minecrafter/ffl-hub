<?php

namespace FFLHub\Distributor\Product;

use FFLHub\Product\ProductMeta;
use FFLHub\Product\CategoryInstaller;
use FFLHub\Settings\Options;

use WP_Error;
use WC_Product_Simple;

class DistributorProductHelper
{
    public static function create_woo_product_from_payload(
        string $upc,
        DistributorProductPayload $selected_product,
        string $selected_dist_id,
        string $selected_dist_label,
        array $carrier_distributors
    ) {
        // A) Guard: prevent duplicates (UPC already exists)
        $existing_id = self::find_existing_product_id_by_upc($upc);
        if ($existing_id !== null) {
            return self::build_existing_product_response($existing_id);
        }

        // B) Compute retail price (based on selected payload)
        $recommended_price = self::get_reccomended_price_from_payload($selected_product);

        if ($recommended_price === null || $recommended_price <= 0) {
            return new WP_Error(
                'fflhub_no_price',
                __('Could not compute a valid retail price for this product.', 'ffl-hub')
            );
        }

        // C) Build WC product core fields (name/desc/sku/price/stock/status)
        $product = self::build_wc_product_from_payload(
            $upc,
            $selected_product,
            $recommended_price
        );

        // D) Apply categories (recommended_category path)
        self::apply_categories_from_payload($product, $selected_product);

        // E) Save product and get ID
        $product_id = self::save_and_get_id($product);
        if (! $product_id) {
            return new WP_Error(
                'fflhub_insert_failed',
                __('Could not create WooCommerce product via CRUD API.', 'ffl-hub')
            );
        }

        // F) Apply FFLHub meta (Option 2: map/msrp/qty/ffl from selected payload)
        self::apply_fflhub_meta_from_payload(
            $product,
            $upc,
            $selected_dist_id,
            $selected_product,
            $recommended_price
        );

        // G) Import images from all carriers (selected distributor marked primary)
        self::import_images_from_carriers(
            $product_id,
            $upc,
            $carrier_distributors,
            $selected_dist_id
        );

        // Persist meta
        $product->save();

        // H) Return success response
        return self::build_created_product_response($product_id);
    }

    /**
     * A) Find existing product by UPC meta.
     */
    private static function find_existing_product_id_by_upc(string $upc): ?int
    {
        $existing = get_posts(
            [
                'post_type'      => 'product',
                'post_status'    => ['publish', 'draft', 'pending', 'private'],
                'posts_per_page' => 1,
                'meta_query'     => [
                    [
                        'key'   => ProductMeta::FFLHUB_UPC_META,
                        'value' => $upc,
                    ],
                ],
                'fields'         => 'ids',
            ]
        );

        if (empty($existing)) {
            return null;
        }

        return (int) $existing[0];
    }

    private static function build_existing_product_response(int $existing_id): array
    {
        $edit_link = get_edit_post_link($existing_id, '');

        $message = sprintf(
            /* translators: 1: product ID, 2: edit URL */
            __('A WooCommerce product already exists for this UPC (ID #%1$d). <a href="%2$s">Edit product</a>.', 'ffl-hub'),
            $existing_id,
            esc_url($edit_link)
        );

        return [
            'message' => $message,
            'type'    => 'warning',
        ];
    }

    /**
     * C) Build the WC product core fields from the selected payload.
     */
    private static function build_wc_product_from_payload(
        string $upc,
        DistributorProductPayload $selected_product,
        float $recommended_price
    ): WC_Product_Simple {
        $product = new WC_Product_Simple();

        $name        = $selected_product->name;
        $sku         = $selected_product->sku;
        $description = $selected_product->description;
        $qty         = (int) $selected_product->quantity;

        // Title / Description
        $product->set_name($name ?: $sku ?: $upc);
        $product->set_description($description);

        // SKU
        $sku_to_use = $sku ?: $upc;
        if ($sku_to_use) {
            $product->set_sku($sku_to_use);
        }

        // Price
        $product->set_regular_price(wc_format_decimal($recommended_price, 2));

        // Stock / inventory (Option 2: selected distributor only)
        $product->set_manage_stock(true);
        $product->set_stock_quantity($qty);
        $product->set_stock_status($qty > 0 ? 'instock' : 'outofstock');

        // Status / visibility
        $product->set_status('draft');
        $product->set_catalog_visibility('visible');

        return $product;
    }

    /**
     * D) Apply recommended categories if recommended_category is a path array.
     */
    private static function apply_categories_from_payload(
        WC_Product_Simple $product,
        DistributorProductPayload $selected_product
    ): void {
        $recommended_category = $selected_product->recommended_category ?? null;

        if (! is_array($recommended_category) || empty($recommended_category)) {
            return;
        }

        $term_ids = CategoryInstaller::get_term_ids_for_path($recommended_category);

        if (! is_array($term_ids) || empty($term_ids)) {
            return;
        }

        $term_ids = array_values(array_unique(array_map('intval', $term_ids)));

        if (! empty($term_ids)) {
            $product->set_category_ids($term_ids);
        }
    }

    /**
     * E) Save and return product ID.
     */
    private static function save_and_get_id(WC_Product_Simple $product): int
    {
        $product->save();
        return (int) $product->get_id();
    }

    /**
     * F) Write all plugin meta (based on the selected payload; Option 2 behavior).
     */
    private static function apply_fflhub_meta_from_payload(
        WC_Product_Simple $product,
        string $upc,
        string $selected_dist_id,
        DistributorProductPayload $selected_product,
        float $recommended_price
    ): void {
        $dealer_price = $selected_product->price;
        $true_cost    = $selected_product->true_cost;

        // Option 2: selected distributor MAP/MSRP/FFL only
        $map          = $selected_product->map;
        $msrp         = $selected_product->msrp;
        $ffl_required = $selected_product->ffl_required;

        $product->set_global_unique_id($upc);

        $product->update_meta_data(ProductMeta::FFLHUB_UPC_META, $upc);
        $product->update_meta_data(ProductMeta::FFLHUB_MANAGED_META, true);
        $product->update_meta_data(ProductMeta::FFLHUB_SOURCE_DISTRIBUTOR_META, $selected_dist_id);

        $product->update_meta_data(ProductMeta::FFLHUB_LAST_TRUE_COST_META, $true_cost);
        $product->update_meta_data(ProductMeta::FFLHUB_LAST_DEALER_PRICE_META, $dealer_price);

        $product->update_meta_data(ProductMeta::FFLHUB_LAST_MAP_META, $map);
        $product->update_meta_data(ProductMeta::FFLHUB_LAST_MSRP_META, $msrp);

        $product->update_meta_data(ProductMeta::FFLHUB_LAST_COMPUTED_PRICE_META, $recommended_price);
        $product->update_meta_data(ProductMeta::FFLHUB_MARKUP_MODE_META, 1);
        $product->update_meta_data(ProductMeta::FFLHUB_MARKUP_PERCENT_META, 0);

        $product->update_meta_data(ProductMeta::FFLHUB_FFL_REQUIRED_META, $ffl_required ? 1 : 0);
        $product->update_meta_data(ProductMeta::FFLHUB_NFA_ITEM_META, 0);

        $product->update_meta_data(ProductMeta::FFLHUB_LAST_SYNC_META, current_time('mysql'));
    }

    /**
     * G) Import images from all distributors (selected distributor marked primary).
     */
    private static function import_images_from_carriers(
        int $product_id,
        string $upc,
        array $carrier_distributors,
        string $selected_dist_id
    ): void {
        if (! class_exists(DistributorProductImages::class)) {
            return;
        }

        foreach ($carrier_distributors as $dist_id => $info) {
            if (
                empty($info['payload']) ||
                ! ($info['payload'] instanceof DistributorProductPayload)
            ) {
                continue;
            }

            $is_primary = ((string) $dist_id === (string) $selected_dist_id);

            DistributorProductImages::import_images_for_distributor(
                $product_id,
                $upc,
                $info['payload'],
                (string) $dist_id,
                $is_primary
            );
        }
    }

    private static function build_created_product_response(int $product_id): array
    {
        $edit_link = get_edit_post_link($product_id, '');

        $message = sprintf(
            /* translators: 1: product ID, 2: edit URL */
            __('Created WooCommerce product ID #%1$d. <a href="%2$s">Edit product</a>.', 'ffl-hub'),
            $product_id,
            esc_url($edit_link)
        );

        return [
            'message' => $message,
            'type'    => 'success',
        ];
    }

    public static function get_reccomended_price_from_payload(DistributorProductPayload $selected_product): ?float
    {
        $dealer_price   = $selected_product->price;
        $true_cost      = $selected_product->true_cost;
        $markup_percent = Options::get_global_markup() / 100;

        $base_price = ($true_cost !== null)
            ? $true_cost * (1 + $markup_percent)
            : $dealer_price;

        $base_price = (float) $base_price;

        // round up to nearest int, subtract a cent
        $recommended_price = ceil($base_price) - 0.01;

        return $recommended_price;
    }
}
